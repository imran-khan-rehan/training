package com.redmath.Bank.App.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserController {
    @Autowired
  private UserService userService;
    @GetMapping("/home")
    public String home(){
        return "hello at home";
    }
    @GetMapping("/all")
    public List<User> getAll()
    {
        return userService.findAll();
    }
    @PostMapping ("/all")
    public ResponseEntity<User> createUser(@RequestBody User user)
    {
        User savedUser=userService.save(user);
        return  ResponseEntity.ok(savedUser);
    }
}
