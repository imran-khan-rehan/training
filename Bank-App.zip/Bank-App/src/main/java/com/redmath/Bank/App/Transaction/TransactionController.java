package com.redmath.Bank.App.Transaction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TransactionController {
    private static final Logger log = LoggerFactory.getLogger(TransactionController.class);
    @Autowired
    private TransactionService tranctionService;
    @GetMapping("/alltrans")
    public ResponseEntity<List<Transaction>> getall()
    {
        return ResponseEntity.ok(tranctionService.getAll());
    }
    @PostMapping("/create")
    public ResponseEntity<Transaction> create(@RequestBody Transaction transaction)
    {
        log.info("iam in create");
        Transaction saved=tranctionService.save(transaction);
        return ResponseEntity.ok(saved);
    }
}
